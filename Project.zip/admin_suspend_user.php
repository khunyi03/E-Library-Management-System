<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo "Unauthorized";
    exit;
}

$userId = $_POST['user_id'] ?? null;

if (!$userId) {
    echo "Invalid user ID.";
    exit;
}

$stmt = $pdo->prepare("UPDATE users SET suspended = 1 WHERE user_id = ?");
$stmt->execute([$userId]);

echo "User suspended.";
