<?php
require 'db.php'; // your actual db connection is $pdo

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = $_POST['user_id'] ?? null;
    $action = $_POST['action'] ?? '';

    if (!$userId || !in_array($action, ['suspend', 'unsuspend', 'delete'])) {
        exit('Invalid input.');
    }

    try {
        if ($action === 'suspend') {
            $stmt = $pdo->prepare("UPDATE users SET suspended = 1 WHERE user_id = ?");
            $stmt->execute([$userId]);
            echo 'suspended';
        } elseif ($action === 'unsuspend') {
            $stmt = $pdo->prepare("UPDATE users SET suspended = 0 WHERE user_id = ?");
            $stmt->execute([$userId]);
            echo 'unsuspended';
        } elseif ($action === 'delete') {
            $stmt = $pdo->prepare("DELETE FROM users WHERE user_id = ?");
            $stmt->execute([$userId]);
            echo 'deleted';
        }
    } catch (Exception $e) {
        echo 'Error: ' . $e->getMessage();
    }
}
?>
