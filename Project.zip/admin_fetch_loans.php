<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$stmt = $pdo->query("
    SELECT 
        loans.loan_id,
        books.title AS book_title,
        users.username AS user,
        loans.borrowed_on,
        loans.due_date,
        loans.returned_on
    FROM loans
    JOIN books ON loans.book_id = books.book_id
    JOIN users ON loans.user_id = users.user_id
    ORDER BY loans.borrowed_on DESC
");

echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
