<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo 'Unauthorized';
    exit;
}

$action = $_POST['action'] ?? '';
$book_id = $_POST['book_id'] ?? null;
$loan_id = $_POST['loan_id'] ?? null;
$user_id = $_SESSION['user_id'];

if ($action === 'borrow' && $book_id) {
    // Borrowing a book
    $stmt = $pdo->prepare("SELECT status FROM books WHERE book_id = ?");
    $stmt->execute([$book_id]);
    $book = $stmt->fetch();

    if (!$book || $book['status'] !== 'available') {
        echo 'Book not available';
        exit;
    }

    // Insert new loan
    $due_date = date('Y-m-d', strtotime('+14 days'));
    $pdo->prepare("INSERT INTO loans (user_id, book_id, borrowed_on, due_date) VALUES (?, ?, NOW(), ?)")
        ->execute([$user_id, $book_id, $due_date]);

    $pdo->prepare("UPDATE books SET status = 'borrowed' WHERE book_id = ?")->execute([$book_id]);

    echo 'borrowed';
    exit;
}

if ($action === 'return' && $loan_id) {
    // Returning a book by loan_id
    $stmt = $pdo->prepare("SELECT book_id FROM loans WHERE loan_id = ? AND returned_on IS NULL");
    $stmt->execute([$loan_id]);
    $loan = $stmt->fetch();

    if (!$loan) {
        echo 'Loan not found or already returned';
        exit;
    }

    $book_id = $loan['book_id'];

    $pdo->prepare("UPDATE loans SET returned_on = NOW() WHERE loan_id = ?")->execute([$loan_id]);
    $pdo->prepare("UPDATE books SET status = 'available' WHERE book_id = ?")->execute([$book_id]);

    echo 'returned';
    exit;
}

echo 'Invalid request';
exit;
