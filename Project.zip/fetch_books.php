<?php
require 'db.php';

$title = $_GET['title'] ?? '';
$genre = $_GET['genre'] ?? '';
$availability = $_GET['availability'] ?? '';

$sql = "SELECT * FROM books WHERE 1";
$params = [];

if ($title !== '') {
    $sql .= " AND title LIKE ?";
    $params[] = "%" . $title . "%";
}

if ($genre !== '') {
    $sql .= " AND genre = ?";
    $params[] = $genre;
}

if ($availability !== '') {
    $sql .= " AND status = ?";
    $params[] = $availability;
}

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$books = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($books);
